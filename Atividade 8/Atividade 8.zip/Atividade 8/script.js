let idades = [];
let total = 0;

let pessimo = 0;
let otimo = 0;
let bom = 0;

let feminino = 0;
let masculino = 0;
let outros = 0;

function adicionar() {
    let idade = Number(document.getElementById("idade").value);
    let sexo = document.getElementById("sexo").value;
    let opiniao = Number(document.getElementById("opiniao").value);

    if (!idade || !sexo || !opiniao) {
        alert("Preencha todos os campos!");
        return;
    }

    idades.push(idade);
    total++;

    // opinião
    if (opiniao === 1) pessimo++;
    if (opiniao === 3) bom++;
    if (opiniao === 4) otimo++;

    // sexo
    if (sexo === "feminino") feminino++;
    else if (sexo === "masculino") masculino++;
    else outros++;

    alert("Resposta adicionada!");

    // limpar campos
    document.getElementById("idade").value = "";
    document.getElementById("sexo").value = "";
    document.getElementById("opiniao").value = "";
}

function calcular() {
    if (total === 0) {
        alert("Nenhuma resposta!");
        return;
    }

    let soma = idades.reduce((a, b) => a + b, 0);
    let media = soma / total;

    let maior = Math.max(...idades);
    let menor = Math.min(...idades);

    let porcentagemOtimoBom = ((otimo + bom) / total) * 100;

    document.getElementById("resultado").innerHTML =
        "Média das idades: " + media.toFixed(2) + "<br>" +
        "Maior idade: " + maior + "<br>" +
        "Menor idade: " + menor + "<br>" +
        "Quantidade de péssimo: " + pessimo + "<br>" +
        "Porcentagem ótimo + bom: " + porcentagemOtimoBom.toFixed(2) + "%<br>" +
        "Feminino: " + feminino + "<br>" +
        "Masculino: " + masculino + "<br>" +
        "Outros: " + outros;
}