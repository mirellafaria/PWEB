let pessoas = [];

function adicionar() {
    let idade = parseInt(document.getElementById("idade").value);
    let sexo = document.getElementById("sexo").value;
    let opiniao = parseInt(document.getElementById("opiniao").value);

    if (isNaN(idade)) {
        alert("Digite uma idade válida!");
        return;
    }

    pessoas.push({ idade, sexo, opiniao });

    document.getElementById("idade").value = "";
    alert("Pessoa adicionada!");
}

function calcular() {
    if (pessoas.length === 0) {
        alert("Nenhum dado inserido!");
        return;
    }

    let somaIdade = 0;
    let maisVelho = pessoas[0].idade;
    let maisNovo = pessoas[0].idade;

    let pessimo = 0;
    let otimoBom = 0;

    let feminino = 0;
    let masculino = 0;
    let outros = 0;

    for (let p of pessoas) {
        somaIdade += p.idade;

        if (p.idade > maisVelho) maisVelho = p.idade;
        if (p.idade < maisNovo) maisNovo = p.idade;

        if (p.opiniao === 1) pessimo++;
        if (p.opiniao === 4 || p.opiniao === 3) otimoBom++;

        if (p.sexo === "feminino") feminino++;
        else if (p.sexo === "masculino") masculino++;
        else outros++;
    }

    let media = somaIdade / pessoas.length;
    let porcentagem = (otimoBom / pessoas.length) * 100;

    document.getElementById("resultado").innerHTML = `
        <strong>Resultados:</strong><br>
        Média das idades: ${media.toFixed(2)}<br>
        Idade mais velha: ${maisVelho}<br>
        Idade mais nova: ${maisNovo}<br>
        Quantidade de "Péssimo": ${pessimo}<br>
        Porcentagem de "Ótimo e Bom": ${porcentagem.toFixed(2)}%<br>
        Mulheres: ${feminino}<br>
        Homens: ${masculino}<br>
        Outros: ${outros}
    `;
}