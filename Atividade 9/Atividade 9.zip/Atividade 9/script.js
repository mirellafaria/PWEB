
function maiorNumero(a, b, c) {
    return Math.max(a, b, c);
}

function mostrarMaior() {
    let a = Number(n1.value);
    let b = Number(n2.value);
    let c = Number(n3.value);

    r1.innerHTML = "Maior: " + maiorNumero(a, b, c);
}


function ordemCrescente(a, b, c) {
    return [a, b, c].sort((x, y) => x - y);
}

function mostrarOrdem() {
    let a = Number(c1.value);
    let b = Number(c2.value);
    let c = Number(c3.value);

    r2.innerHTML = "Ordem: " + ordemCrescente(a, b, c).join(", ");
}

function ehPalindromo(texto) {
    let formatado = texto.toLowerCase().replace(/\s/g, "");
    let invertido = formatado.split("").reverse().join("");

    return formatado === invertido;
}

function verificarPalindromo() {
    let texto = document.getElementById("texto").value;

    r3.innerHTML = ehPalindromo(texto)
        ? "É palíndromo"
        : "Não é palíndromo";
}

function subconjunto(p1, p2) {
    if (!p1 || !p2) return "erro";

    p1 = p1.toLowerCase();
    p2 = p2.toLowerCase();

    if (p1.includes(p2)) {
        return "é um subconjunto";
    } else {
        return "não é um subconjunto";
    }
}

function verificarSubconjunto() {
    let p1 = document.getElementById("p1").value;
    let p2 = document.getElementById("p2").value;

    r4.innerHTML = subconjunto(p1, p2);
}


function diaSemana(data) {
    let dias = [
        "Domingo", "Segunda-feira", "Terça-feira",
        "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"
    ];

    let partes = data.split("-"); // formato yyyy-mm-dd
    let ano = parseInt(partes[0]);
    let mes = parseInt(partes[1]) - 1; // mês começa do 0
    let dia = parseInt(partes[2]);

    let d = new Date(ano, mes, dia);

    return dias[d.getDay()];
}

function verDia() {
    let data = document.getElementById("data").value;

    if (!data) {
        r5.innerHTML = "Selecione uma data!";
        return;
    }

    r5.innerHTML = "Dia: " + diaSemana(data);
}