const janelaImg = document.getElementById('janela');
const titulo = document.getElementById('titulo');

const imgFechada = "https://m.media-amazon.com/images/I/71Ww3y1TR4L._AC_UF894,1000_QL80_.jpg";
const imgAberta = "https://previews.123rf.com/images/serjio74/serjio741604/serjio74160400032/54827532-closed-window-in-the-new-building-at-sunset.jpg";
const imgQuebrada = "https://viverdeblog.com/wp-content/uploads/2018/05/f542232f-276d-42e3-9211-057e49b6d27f.jpg";

let estaQuebrada = false;

janelaImg.addEventListener('mouseenter', () => {
    if (!estaQuebrada) {
        janelaImg.src = imgAberta;
        titulo.innerText = "Janela Aberta";
    }
});

janelaImg.addEventListener('mouseleave', () => {
    if (!estaQuebrada) {
        janelaImg.src = imgFechada;
        titulo.innerText = "Janela Fechada";
    }
});

janelaImg.addEventListener('click', () => {
    estaQuebrada = true;
    janelaImg.src = imgQuebrada;
    titulo.innerText = "Janela Quebrada";
    titulo.style.color = "red";
});