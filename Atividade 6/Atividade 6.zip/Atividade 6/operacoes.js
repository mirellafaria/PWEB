let num1 = parseFloat(prompt("Digite o primeiro numero:"));
let num2 = parseFloat(prompt("Digite o segundo numero:"));

let soma = num1 + num2;
let subtracao = num1 - num2;
let produto = num1 * num2;
let divisao = num1 / num2;
let resto = num1 % num2;

alert(
  "Soma: " + soma +
  "\nSubtracao: " + subtracao +
  "\nProduto: " + produto +
  "\nDivisao: " + divisao +
  "\nResto: " + resto
);