// Função Construtora
function Retangulo(x, y) {
    this.base = parseFloat(x);
    this.altura = parseFloat(y);

    // Método para calcular a área
    this.calcularArea = function() {
        return this.base * this.altura;
    };
}

function gerarCalculo() {
    // Capturando os valores dos inputs
    const valorX = document.getElementById('base').value;
    const valorY = document.getElementById('altura').value;
    const display = document.getElementById('resultado');

    // Validação simples
    if (valorX > 0 && valorY > 0) {
        // Criando o objeto usando a função construtora
        const meuRetangulo = new Retangulo(valorX, valorY);
        
        // Executando o método e exibindo na tela
        const area = meuRetangulo.calcularArea();
        display.innerHTML = `Área: ${area} unidades²`;
    } else {
        display.style.color = "red";
        display.innerHTML = "Insira valores válidos!";
    }
}

