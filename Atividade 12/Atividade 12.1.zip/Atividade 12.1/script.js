function Retangulo(x, y) {
    this.base = parseFloat(x);
    this.altura = parseFloat(y);

    this.calcularArea = function() {
        return this.base * this.altura;
    };
}

function gerarCalculo() {
    
    const valorX = document.getElementById('base').value;
    const valorY = document.getElementById('altura').value;
    const display = document.getElementById('resultado');

    
    if (valorX > 0 && valorY > 0) {
        const meuRetangulo = new Retangulo(valorX, valorY);
        
        const area = meuRetangulo.calcularArea();
        display.innerHTML = `Área: ${area} unidades²`;
    } else {
        display.style.color = "red";
        display.innerHTML = "Insira valores válidos!";
    }
}

