class Conta {
    constructor() {
        this._nome = "";
        this._banco = "";
        this._numero = "";
        this._saldo = 0;
    }

    get nome() { return this._nome; }
    set nome(valor) { this._nome = valor; }

    get banco() { return this._banco; }
    set banco(valor) { this._banco = valor; }

    get numero() { return this._numero; }
    set numero(valor) { this._numero = valor; }

    get saldo() { return this._saldo; }
    set saldo(valor) { this._saldo = valor; }
}

class Corrente extends Conta {
    constructor() {
        super();
        this._limiteEspecial = 0;
    }
    get limiteEspecial() { return this._limiteEspecial; }
    set limiteEspecial(valor) { this._limiteEspecial = valor; }
}

class Poupanca extends Conta {
    constructor() {
        super();
        this._juros = 0;
        this._vencimento = "";
    }
    get juros() { return this._juros; }
    set juros(valor) { this._juros = valor; }

    get vencimento() { return this._vencimento; }
    set vencimento(valor) { this._vencimento = valor; }
}

const contaC = new Corrente();
contaC.nome = "Ricardo Almeida"; 
contaC.banco = "Banco do Brasil";
contaC.numero = "12345-6";
contaC.saldo = 1500.00;
contaC.limiteEspecial = 800.00;

const contaP = new Poupanca();
contaP.nome = "Fernanda Souza";
contaP.banco = "Caixa";
contaP.numero = "98765-0";
contaP.saldo = 10000.00;
contaP.juros = 0.65;
contaP.vencimento = "Dia 15";

const div = document.getElementById('resultado');
div.innerHTML = `
    <div class="card">
        <h2>Conta Corrente </h2>
        <p><strong>Titular:</strong> ${contaC.nome}</p>
        <p><strong>Banco:</strong> ${contaC.banco}</p>
        <p><strong>Saldo:</strong> R$ ${contaC.saldo}</p>
        <p><strong>Limite:</strong> R$ ${contaC.limiteEspecial}</p>
    </div>

    <div class="card">
        <h2>Conta Poupança </h2>
        <p><strong>Titular:</strong> ${contaP.nome}</p>
        <p><strong>Banco:</strong> ${contaP.banco}</p>
        <p><strong>Saldo:</strong> R$ ${contaP.saldo}</p>
        <p><strong>Juros:</strong> ${contaP.juros}%</p>
        <p><strong>Vencimento:</strong> ${contaP.vencimento}</p>
    </div>
`;