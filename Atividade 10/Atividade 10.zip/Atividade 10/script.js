
function calcularIMC(peso, altura) {
    return peso / (altura * altura);
}

function classificarIMC(imc) {
    if (imc < 18.5) {
        return "Magreza";
    } else if (imc < 25) {
        return "Normal";
    } else if (imc < 30) {
        return "Sobrepeso";
    } else if (imc < 40) {
        return "Obesidade";
    } else {
        return "Obesidade grave";
    }
}

function calcular() {
    let altura = parseFloat(document.getElementById("altura").value);
    let peso = parseFloat(document.getElementById("peso").value);

    if (isNaN(altura) || isNaN(peso) || altura <= 0 || peso <= 0) {
        document.getElementById("resultado").innerText = "Preencha valores válidos!";
        return;
    }

    let imc = calcularIMC(peso, altura);
    let classificacao = classificarIMC(imc);

    document.getElementById("resultado").innerText =
        "IMC: " + imc.toFixed(2) + " - " + classificacao;
}